import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { TabScreen } from "@/components/adopet/AppShell";
import { FavButton } from "@/components/adopet/bits";
import { AdoptButton } from "@/components/adopet/AdoptDialog";
import { ChatButton } from "@/components/adopet/ChatButton";
import { PhotoCarousel } from "@/components/adopet/PhotoCarousel";
import { useEffect, useState } from "react";
import { fetchDbPets } from "@/lib/db-pets";
import { coatLabel, formatAge, getPet, getShelter, sexLabel, sizeLabel } from "@/data/pets";

export const Route = createFileRoute("/pet/$id")({
  head: () => ({ meta: [
    { title: "Detalhes do pet — ADOPET" },
    { name: "description", content: "Conheça o pet, sua saúde, personalidade e abrigo." },
    { property: "og:title", content: "Detalhes do pet — ADOPET" },
    { property: "og:description", content: "Conheça o pet, sua saúde, personalidade e abrigo." },
  ] }),
  component: PetPage,
});

function PetPage() {
  const { id } = Route.useParams();
  const [, setTick] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const pet = getPet(id);
  useEffect(() => { if (!getPet(id)) fetchDbPets().then(() => { setLoaded(true); setTick((t) => t + 1); }); else setLoaded(true); }, [id]);
  if (!pet && !loaded) return <TabScreen><p className="p-6 text-sm text-muted-foreground">Carregando...</p></TabScreen>;
  if (!pet) return <TabScreen><p className="p-6">Pet não encontrado.</p></TabScreen>;
  const s = getShelter(pet.shelterId);
  const yes = (b: boolean) => (b ? "Sim" : "Não");
  return (
    <TabScreen>
      <div className="relative">
        <PhotoCarousel photos={pet.photos} name={pet.name} />
        <Link to="/" aria-label="Voltar" className="absolute left-3 top-3 grid size-9 place-items-center rounded-full bg-card shadow-card"><ArrowLeft className="size-5" /></Link>
        <FavButton petId={pet.id} className="absolute right-3 top-3" />
      </div>
      <div className="space-y-4 p-5">
        <div><h1 className="text-2xl font-bold">{pet.name}</h1><p className="text-sm text-muted-foreground">{pet.breed} · {formatAge(pet.ageYears)}</p></div>
        <dl className="grid grid-cols-2 gap-2 text-sm">
          {[["Porte", sizeLabel[pet.size]], ["Pelagem", coatLabel[pet.coat]], ["Sexo", sexLabel[pet.sex]], ["Vacinado", yes(pet.vaccinated)], ["Vermifugado", yes(pet.dewormed)], ["Castrado", yes(pet.neutered)]].map(([k, v]) => (
            <div key={k} className="rounded-xl bg-card p-3 shadow-card"><dt className="text-xs text-muted-foreground">{k}</dt><dd className="font-semibold">{v}</dd></div>
          ))}
        </dl>
        <p className="text-sm">{pet.personality}</p>
        <div className="rounded-xl bg-teal-soft p-3 text-sm text-teal"><p className="font-semibold">{s.name}</p><p>{s.city} · {s.phone}</p></div>
        <div className="space-y-2">
          {pet.status === "adotado"
            ? <p className="rounded-xl bg-teal-soft p-3 text-center text-sm font-semibold text-teal">Doação concluída: este pet já foi adotado</p>
            : pet.status === "em_processo"
              ? <p className="rounded-xl bg-accent p-3 text-center text-sm font-semibold text-accent-foreground">Em processo de adoção</p>
              : <AdoptButton pet={pet} />}
          {pet.status !== "adotado" && <ChatButton pet={pet} />}
        </div>
      </div>
    </TabScreen>
  );
}
